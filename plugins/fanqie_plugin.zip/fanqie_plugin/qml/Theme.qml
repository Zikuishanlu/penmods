pragma Singleton

import QtQuick 2.12

// 全局配色与尺寸，改外观只动这里
QtObject {
    readonly property color bg:        "#14161C"
    readonly property color surface:   "#1E2128"
    readonly property color elevated:  "#2A2E37"
    readonly property color divider:   "#2E323B"

    readonly property color accent:    "#7C9CFF"
    readonly property color accentDim: "#3D4C7A"
    readonly property color success:   "#4FD1C5"
    readonly property color danger:    "#FF6B6B"

    readonly property color text:      "#F2F4F8"
    readonly property color textDim:   "#9AA3B2"
    readonly property color textFaint: "#5C6470"

    readonly property int toolbarWidth: 36
    readonly property int navItemHeight: 33

    readonly property int fontTitle: 14
    readonly property int fontBody: 12
    readonly property int fontSmall: 10

    // 全局字体；设备上没有微软雅黑时会自动回退到系统默认
    readonly property string fontFamily: "Microsoft YaHei"

    readonly property int radius: 8
    readonly property int radiusSmall: 5
}
