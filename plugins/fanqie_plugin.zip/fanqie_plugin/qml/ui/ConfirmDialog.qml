import QtQuick 2.12
import ".."

// 通用确认框
Item {
    id: dialog

    property string tipText: "确定？"
    property string confirmText: "删除"
    signal confirmed()
    signal cancelled()

    anchors.fill: parent
    visible: false
    z: 900

    function show() {
        visible = true
        opacity = 0
        appear.start()
    }

    function close() {
        disappear.start()
    }

    NumberAnimation {
        id: appear
        target: dialog
        property: "opacity"
        to: 1
        duration: 100
    }

    NumberAnimation {
        id: disappear
        target: dialog
        property: "opacity"
        to: 0
        duration: 120
        onStopped: dialog.visible = false
    }

    // 遮罩
    MouseArea {
        anchors.fill: parent
        onClicked: dialog.cancelled()
    }

    Rectangle {
        anchors.centerIn: parent
        width: 190
        height: 92
        radius: Theme.radius
        color: Theme.surface
        border.color: Theme.divider
        border.width: 1

        Column {
            anchors.fill: parent
            anchors.margins: 10
            spacing: 8

            Text {
                font.family: Theme.fontFamily
                width: parent.width
                font.pixelSize: Theme.fontBody
                color: Theme.text
                wrapMode: Text.Wrap
                maximumLineCount: 2
                elide: Text.ElideRight
                horizontalAlignment: Text.AlignHCenter
                text: dialog.tipText
            }

            Row {
                anchors.horizontalCenter: parent.horizontalCenter
                spacing: 12

                Btn {
                    btnWidth: 76; btnHeight: 28
                    text: "取消"
                    fill: Theme.elevated
                    textColor: Theme.textDim
                    onClicked: {
                        dialog.cancelled()
                        dialog.close()
                    }
                }

                Btn {
                    btnWidth: 76; btnHeight: 28
                    text: dialog.confirmText
                    fill: Theme.danger
                    onClicked: {
                        dialog.confirmed()
                        dialog.close()
                    }
                }
            }
        }
    }
}
