import QtQuick 2.12
import ".."

// 页面栈：Loader 实现，push/pop/replace，返回键逻辑由外部调用
// 页面通过注入的 stack 属性调用 push/pop（见 load()）
// 每个导航各自持有一个 PageStack 实例（main.qml 里的控制器切换显示）；
// 跨栈操作（打开阅读器）经 controller 委托给控制器。
Item {
    id: stack

    property string pageDir: ""
    property string currentPage: ""
    property var rootItem: null   // 插件根，传给页面做全屏覆盖物（键盘等）
    property var controller: null // 主控制器（main.qml），openReader 等跨栈操作
    signal stackChanged()

    // 供页面使用的导航句柄
    property var api: ({
        push: push,
        pop: pop,
        replace: replace,
        depth: depth,
        currentPage: currentPage,
        openReader: function(props) {
            if (controller)
                controller.openReader(props)
        },
        back: function() {
            if (controller)
                controller.back()
        },
        exit: function() {
            if (rootItem)
                rootItem.backButtonClicked()
        }
    })

    property var _pages: []   // 每项 { name, props }，props 跟页面一起入栈，弹回时原样还原

    function push(page, props) {
        _pages.push({ name: page, props: props || {} })
        load()
    }

    function replace(page, props) {
        if (_pages.length === 0)
            _pages.push({ name: page, props: props || {} })
        else
            _pages[_pages.length - 1] = { name: page, props: props || {} }
        load()
    }

    function pop() {
        if (_pages.length > 1) {
            _pages.pop()
            load()
        }
    }

    function depth() {
        return _pages.length
    }

    // 浅拷贝整条栈（页面名+入参），供"打开阅读器"把当前导航的上下文带进阅读导航
    function pagesCopy() {
        var copy = []
        for (var i = 0; i < _pages.length; ++i) {
            var props = {}
            for (var k in _pages[i].props)
                props[k] = _pages[i].props[k]
            copy.push({ name: _pages[i].name, props: props })
        }
        return copy
    }

    function setPages(list) {
        _pages = list
        load()
    }

    function load() {
        var entry = _pages[_pages.length - 1]
        var props = {}
        for (var k in entry.props)
            props[k] = entry.props[k]
        props.stack = api
        props.pluginRoot = rootItem
        loader.source = ""
        loader.opacity = 0
        loader.setSource(pageDir + entry.name + ".qml", props)
        currentPage = entry.name
        stackChanged()
    }

    Loader {
        id: loader
        anchors.fill: parent
        opacity: 0
        Behavior on opacity {
            NumberAnimation { duration: 120 }
        }
        onLoaded: opacity = 1
    }
}
