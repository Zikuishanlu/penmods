import QtQuick 2.12
import ".."

// 左侧竖向工具栏：导航项可滚动，返回钮固定在底部
Item {
    id: toolbar
    width: Theme.toolbarWidth

    property int currentIndex: 0
    signal navRequested(int index, string page)
    signal backRequested()

    ListModel {
        id: navModel
        ListElement { page: "BookshelfPage";   kind: "bookshelf" }
        ListElement { page: "SearchPage";      kind: "search" }
        ListElement { page: "CategoriesPage";  kind: "category" }
        ListElement { page: "DownloadsPage";   kind: "download" }
        ListElement { page: "HistoryPage";     kind: "history" }
        ListElement { page: "ReaderPage";      kind: "book" }
    }

    Rectangle {
        id: bg
        anchors.fill: parent
        color: Theme.surface
    }

    // 导航项滚动区
    Flickable {
        id: navScroller
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: backButton.top
        contentHeight: navModel.count * Theme.navItemHeight
        clip: true
        boundsBehavior: Flickable.StopAtBounds

        Column {
            id: navColumn
            width: parent.width

            Repeater {
                model: navModel
                delegate: Item {
                    width: navColumn.width
                    height: Theme.navItemHeight
                    scale: navPress.pressed ? 0.88 : 1.0

                    Behavior on scale {
                        NumberAnimation { duration: 90 }
                    }

                    // 选中指示条
                    Rectangle {
                        visible: index === toolbar.currentIndex
                        width: 3
                        height: 16
                        radius: 1.5
                        color: Theme.accent
                        anchors.left: parent.left
                        anchors.verticalCenter: parent.verticalCenter
                    }

                    CanvasIcon {
                        kind: model.kind
                        color: index === toolbar.currentIndex ? Theme.accent : Theme.textDim
                        anchors.centerIn: parent
                    }

                    MouseArea {
                        id: navPress
                        anchors.fill: parent
                        onClicked: {
                            toolbar.currentIndex = index
                            toolbar.navRequested(index, model.page)
                        }
                    }
                }
            }
        }
    }

    // 返回钮
    Item {
        id: backButton
        height: 38
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom

        Rectangle {
            anchors.top: parent.top
            anchors.left: parent.left
            anchors.right: parent.right
            height: 1
            color: Theme.divider
        }

        CanvasIcon {
            kind: "back"
            color: Theme.text
            anchors.centerIn: parent
        }

        MouseArea {
            anchors.fill: parent
            onClicked: toolbar.backRequested()
        }
    }
}
