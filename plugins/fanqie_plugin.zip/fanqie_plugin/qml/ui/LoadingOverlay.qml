import QtQuick 2.12
import ".."

// 加载中覆盖层：半透明底 + 旋转圆弧 + 提示文字，纯视觉不拦截点击
Item {
    id: overlay

    property bool active: false
    property string hint: "加载中…"

    visible: active

    Rectangle {
        anchors.fill: parent
        color: Theme.bg
        opacity: 0.55
    }

    Column {
        anchors.centerIn: parent
        spacing: 8

        Canvas {
            id: spinner
            anchors.horizontalCenter: parent.horizontalCenter
            width: 22
            height: 22

            onPaint: {
                var ctx = getContext("2d")
                ctx.reset()
                ctx.scale(canvasSize.width / width, canvasSize.height / height)
                ctx.strokeStyle = Theme.accent
                ctx.lineWidth = 2
                ctx.lineCap = "round"
                ctx.beginPath()
                ctx.arc(11, 11, 9, 0, 4.4)   // 只画约 250° 的弧，旋转起来像加载圈
                ctx.stroke()
            }

            RotationAnimation {
                target: spinner
                from: 0
                to: 360
                duration: 800
                loops: Animation.Infinite
                running: overlay.active
                property: "rotation"
            }
        }

        Text {
            font.family: Theme.fontFamily
            anchors.horizontalCenter: parent.horizontalCenter
            font.pixelSize: Theme.fontBody
            color: Theme.textDim
            text: overlay.hint
        }
    }
}
