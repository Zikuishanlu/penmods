import QtQuick 2.12
import ".."

// 网络/下载失败错误框：模态提示，点确定关闭
Item {
    id: dialog

    property string title: "错误"
    property string message: ""

    anchors.fill: parent
    visible: false
    z: 960

    function show(t, m) {
        if (t !== undefined && t !== "")
            dialog.title = t
        if (m !== undefined && m !== "")
            dialog.message = m
        visible = true
        opacity = 0
        appear.start()
    }

    function close() {
        disappear.start()
    }

    NumberAnimation {
        id: appear
        target: dialog
        property: "opacity"
        to: 1
        duration: 100
    }

    NumberAnimation {
        id: disappear
        target: dialog
        property: "opacity"
        to: 0
        duration: 120
        onStopped: dialog.visible = false
    }

    // 遮罩
    Rectangle {
        anchors.fill: parent
        color: "#80000000"
    }

    Rectangle {
        anchors.centerIn: parent
        width: 240
        height: 116
        radius: Theme.radius
        color: Theme.surface
        border.color: Theme.divider
        border.width: 1

        Column {
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Text {
                font.family: Theme.fontFamily
                width: parent.width
                font.pixelSize: Theme.fontSmall
                color: Theme.danger
                horizontalAlignment: Text.AlignHCenter
                text: dialog.title
            }

            Text {
                font.family: Theme.fontFamily
                width: parent.width
                font.pixelSize: Theme.fontBody
                color: Theme.text
                wrapMode: Text.Wrap
                maximumLineCount: 3
                elide: Text.ElideRight
                horizontalAlignment: Text.AlignHCenter
                text: dialog.message
            }

            Btn {
                anchors.horizontalCenter: parent.horizontalCenter
                btnWidth: 76; btnHeight: 28
                text: "确定"
                fill: Theme.accent
                onClicked: dialog.close()
            }
        }
    }
}
