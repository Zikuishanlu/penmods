import QtQuick 2.12
import ".."

// 通用按钮：按压缩放回弹动画、enabled 态、可指定配色
Rectangle {
    id: btn

    property alias text: label.text
    property bool enabled: true
    property color fill: Theme.accent
    property color textColor: "white"
    property int pixelSize: Theme.fontBody
    property int btnWidth: 84
    property int btnHeight: 30
    signal clicked()

    width: btnWidth
    height: btnHeight
    radius: btnHeight / 2
    color: enabled ? fill : Theme.divider
    scale: press.pressed ? 0.92 : 1.0

    Behavior on scale {
        SpringAnimation {
            spring: 3
            damping: 0.3
            duration: 220
        }
    }

    Text {
        font.family: Theme.fontFamily
        id: label
        anchors.centerIn: parent
        font.pixelSize: btn.pixelSize
        color: enabled ? textColor : Theme.textFaint
    }

    MouseArea {
        id: press
        anchors.fill: parent
        enabled: btn.enabled
        onClicked: btn.clicked()
    }
}
