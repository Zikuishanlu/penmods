import QtQuick 2.12
import ".."

// 长按弹出的操作菜单，actions 形如 [{label, color}]
Item {
    id: menu

    property var actions: []
    property string title: ""
    signal actionClicked(int index)
    signal dismissed()

    anchors.fill: parent
    visible: false
    z: 800

    function show() {
        visible = true
        opacity = 0
        appear.start()
    }

    function close() {
        disappear.start()
    }

    NumberAnimation {
        id: appear
        target: menu
        property: "opacity"
        to: 1
        duration: 100
    }

    NumberAnimation {
        id: disappear
        target: menu
        property: "opacity"
        to: 0
        duration: 120
        onStopped: menu.visible = false
    }

    MouseArea {
        anchors.fill: parent
        onClicked: {
            menu.dismissed()
            menu.close()
        }
    }

    Column {
        anchors.centerIn: parent
        width: 150
        spacing: 6

        Rectangle {
            width: parent.width
            height: 26
            radius: Theme.radiusSmall
            color: Theme.elevated

            Text {
                font.family: Theme.fontFamily
                anchors.centerIn: parent
                font.pixelSize: Theme.fontSmall
                color: Theme.textDim
                elide: Text.ElideRight
                text: menu.title
                width: parent.width - 16
                horizontalAlignment: Text.AlignHCenter
            }
        }

        Repeater {
            model: menu.actions
            delegate: Rectangle {
                width: 150
                height: 34
                radius: Theme.radiusSmall
                color: Theme.elevated
                scale: press.pressed ? 0.94 : 1.0

                Behavior on scale {
                    NumberAnimation { duration: 90 }
                }

                Text {
                    font.family: Theme.fontFamily
                    anchors.centerIn: parent
                    font.pixelSize: Theme.fontBody
                    color: modelData.color !== undefined ? modelData.color : Theme.text
                    text: modelData.label
                }

                MouseArea {
                    id: press
                    anchors.fill: parent
                    onClicked: {
                        menu.actionClicked(index)
                        menu.close()
                    }
                }
            }
        }
    }
}
