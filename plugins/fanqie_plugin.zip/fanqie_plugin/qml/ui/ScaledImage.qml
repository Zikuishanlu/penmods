import QtQuick 2.12
import ".."

// 图片显示统一入口：限制解码尺寸、异步加载、占位兜底
Image {
    id: scaled

    property int displayWidth: 60
    property int displayHeight: 80
    property string placeholderChar: "书"
    property bool showPlaceholder: true

    width: displayWidth
    height: displayHeight
    sourceSize: Qt.size(displayWidth * 2, displayHeight * 2)
    fillMode: Image.PreserveAspectCrop
    asynchronous: true
    smooth: true
    cache: true

    // 占位块：未就绪时垫底
    Rectangle {
        anchors.fill: parent
        visible: scaled.status !== Image.Ready && showPlaceholder
        color: Theme.elevated
        radius: 4

        Text {
            font.family: Theme.fontFamily
            anchors.centerIn: parent
            font.pixelSize: scaled.displayHeight > 60 ? 22 : 14
            color: Theme.textFaint
            text: scaled.placeholderChar
        }
    }
}
