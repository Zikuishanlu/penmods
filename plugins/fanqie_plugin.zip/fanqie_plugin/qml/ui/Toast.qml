import QtQuick 2.12
import ".."

// 轻提示：底部居中，自动消失
Item {
    id: toast

    property string message: ""
    property int duration: 1600

    anchors.fill: parent
    visible: false

    function show(msg) {
        var text = (msg === undefined || msg === null) ? "" : String(msg)
        if (text === "")
            return

        fadeOut.stop()
        hideTimer.stop()
        toast.message = text
        toast.opacity = 0
        toast.visible = true
        fadeIn.restart()
        hideTimer.restart()
    }

    function hide() {
        fadeOut.start()
    }

    Timer {
        id: hideTimer
        interval: toast.duration
        onTriggered: toast.hide()
    }

    NumberAnimation {
        id: fadeIn
        target: toast
        property: "opacity"
        to: 1
        duration: 120
    }

    NumberAnimation {
        id: fadeOut
        target: toast
        property: "opacity"
        to: 0
        duration: 200
        onStopped: toast.visible = false
    }

    Rectangle {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 12
        width: Math.max(26, Math.min(measure.implicitWidth + 24, toast.width - 24))
        height: 26
        radius: 13
        color: Theme.elevated
        opacity: 0.95

        Text {
            font.family: Theme.fontFamily
            id: measure
            text: toast.message
            font.pixelSize: Theme.fontBody
            visible: false
        }

        Text {
            font.family: Theme.fontFamily
            id: tip
            anchors.centerIn: parent
            text: toast.message
            font.pixelSize: Theme.fontBody
            color: Theme.text
            elide: Text.ElideRight
            maximumLineCount: 1
            width: parent.width - 16
            horizontalAlignment: Text.AlignHCenter
        }
    }
}
