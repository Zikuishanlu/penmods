import QtQuick 2.12

// Canvas 线性图标，2x 渲染保证小尺寸清晰
Canvas {
    id: canvas

    property string kind: "bookshelf"   // bookshelf | search | download | history | book | back | close | trash
    property color color: Theme.text

    implicitWidth: 20
    implicitHeight: 20

    onKindChanged: requestPaint()
    onColorChanged: requestPaint()
    onPaint: draw()

    function draw() {
        var ctx = getContext("2d")
        ctx.reset()
        ctx.scale(canvasSize.width / width, canvasSize.height / height)
        ctx.strokeStyle = color
        ctx.fillStyle = color
        ctx.lineWidth = 1.5
        ctx.lineCap = "round"
        ctx.lineJoin = "round"

        switch (kind) {
        case "bookshelf": drawBookshelf(ctx); break
        case "search": drawSearch(ctx); break
        case "category": drawCategory(ctx); break
        case "download": drawDownload(ctx); break
        case "history": drawHistory(ctx); break
        case "book": drawBook(ctx); break
        case "back": drawBack(ctx); break
        case "close": drawClose(ctx); break
        case "trash": drawTrash(ctx); break
        }
    }

    function drawBookshelf(ctx) {
        // 左书矮，右书高；两本书之间留出间距，避免相邻竖线贴在一起
        ctx.beginPath()
        ctx.moveTo(3, 6)
        ctx.lineTo(3, 15)
        ctx.moveTo(8.5, 6)
        ctx.lineTo(8.5, 15)
        ctx.moveTo(11.5, 3)
        ctx.lineTo(11.5, 15)
        ctx.moveTo(17, 3)
        ctx.lineTo(17, 15)
        ctx.stroke()
        // 书脊
        ctx.beginPath()
        ctx.moveTo(5.75, 6)
        ctx.lineTo(5.75, 15)
        ctx.moveTo(14.25, 3)
        ctx.lineTo(14.25, 15)
        ctx.stroke()
    }

    function drawSearch(ctx) {
        ctx.beginPath()
        ctx.arc(8.5, 8.5, 4.5, 0, Math.PI * 2)
        ctx.moveTo(11.8, 11.8)
        ctx.lineTo(16.5, 16.5)
        ctx.stroke()
    }

    function drawCategory(ctx) {
        // 2×2 宫格，代表分类/发现
        ctx.beginPath()
        ctx.moveTo(5, 5)
        ctx.lineTo(15, 5)
        ctx.moveTo(5, 15)
        ctx.lineTo(15, 15)
        ctx.moveTo(5, 5)
        ctx.lineTo(5, 15)
        ctx.moveTo(15, 5)
        ctx.lineTo(15, 15)
        ctx.moveTo(10, 5)
        ctx.lineTo(10, 15)
        ctx.moveTo(5, 10)
        ctx.lineTo(15, 10)
        ctx.stroke()
    }

    function drawDownload(ctx) {
        // 箭头
        ctx.beginPath()
        ctx.moveTo(10, 2.5)
        ctx.lineTo(10, 10.5)
        ctx.moveTo(6, 7)
        ctx.lineTo(10, 11)
        ctx.lineTo(14, 7)
        ctx.stroke()
        // 托盘
        ctx.beginPath()
        ctx.moveTo(3.5, 15.5)
        ctx.lineTo(16.5, 15.5)
        ctx.stroke()
        ctx.beginPath()
        ctx.moveTo(3.5, 12.5)
        ctx.lineTo(3.5, 15.5)
        ctx.moveTo(16.5, 12.5)
        ctx.lineTo(16.5, 15.5)
        ctx.stroke()
    }

    function drawHistory(ctx) {
        ctx.beginPath()
        ctx.arc(10, 10, 7, 0, Math.PI * 2)
        ctx.moveTo(10, 5.5)
        ctx.lineTo(10, 10)
        ctx.lineTo(13.5, 11.5)
        ctx.stroke()
        ctx.beginPath()
        ctx.arc(10, 10, 1, 0, Math.PI * 2)
        ctx.fill()
    }

    function drawBook(ctx) {
        // 翻开的书：左右两页 + 中缝
        ctx.beginPath()
        ctx.moveTo(3, 4)
        ctx.quadraticCurveTo(6.5, 3, 10, 4.5)
        ctx.lineTo(10, 15.5)
        ctx.quadraticCurveTo(6.5, 14.5, 3, 15.5)
        ctx.closePath()
        ctx.moveTo(17, 4)
        ctx.quadraticCurveTo(13.5, 3, 10, 4.5)
        ctx.lineTo(10, 15.5)
        ctx.quadraticCurveTo(13.5, 14.5, 17, 15.5)
        ctx.closePath()
        ctx.stroke()
    }

    function drawBack(ctx) {
        ctx.beginPath()
        ctx.moveTo(16, 10)
        ctx.lineTo(4, 10)
        ctx.moveTo(4, 10)
        ctx.lineTo(9, 5)
        ctx.moveTo(4, 10)
        ctx.lineTo(9, 15)
        ctx.stroke()
    }

    function drawClose(ctx) {
        ctx.beginPath()
        ctx.moveTo(5, 5)
        ctx.lineTo(15, 15)
        ctx.moveTo(15, 5)
        ctx.lineTo(5, 15)
        ctx.stroke()
    }

    function drawTrash(ctx) {
        // 盖子
        ctx.beginPath()
        ctx.moveTo(4, 6)
        ctx.lineTo(16, 6)
        ctx.moveTo(8.5, 3.5)
        ctx.lineTo(11.5, 3.5)
        ctx.stroke()
        // 桶身
        ctx.beginPath()
        ctx.moveTo(6, 7.5)
        ctx.lineTo(6.5, 16)
        ctx.lineTo(13.5, 16)
        ctx.lineTo(14, 7.5)
        ctx.stroke()
        // 桶身纹路
        ctx.beginPath()
        ctx.moveTo(9, 9)
        ctx.lineTo(9, 14)
        ctx.moveTo(11.5, 9)
        ctx.lineTo(11.5, 14)
        ctx.stroke()
    }
}
