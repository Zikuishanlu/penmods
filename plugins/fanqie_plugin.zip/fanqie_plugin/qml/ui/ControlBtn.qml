import QtQuick 2.12
import ".."

// 阅读器控制条小按钮（带按压回弹）
Rectangle {
    id: btn

    property alias text: label.text
    property bool enabled: true
    property int btnHeight: 30
    signal clicked()

    width: label.contentWidth + 14
    height: btnHeight
    radius: btnHeight / 2
    color: enabled ? Theme.surface : Theme.divider
    scale: press.pressed ? 0.88 : 1.0

    Behavior on scale {
        SpringAnimation {
            spring: 3
            damping: 0.3
            duration: 200
        }
    }

    Text {
        id: label
        anchors.centerIn: parent
        font.family: Theme.fontFamily
        font.pixelSize: Theme.fontSmall
        color: enabled ? Theme.text : Theme.textFaint
    }

    MouseArea {
        id: press
        anchors.fill: parent
        enabled: btn.enabled
        onClicked: btn.clicked()
    }
}
