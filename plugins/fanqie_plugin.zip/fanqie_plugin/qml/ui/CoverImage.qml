import QtQuick 2.12
import ".."

// 封面：只读本地缓存（C++ ensureCover 预取），未缓存时显示占位块，
// 下载完成经 coversUpdated 自动刷新——所有网络请求都在 C++ 侧。
// tapToRefresh 开启后点封面主动刷新：重新拉取网络封面，已下载的书
// 直接覆盖书目录里的封面文件（fanqie.refreshCover）
ScaledImage {
    id: cover

    property string bookId: ""
    property string coverUrl: ""
    property bool tapToRefresh: false

    source: bookId === "" ? "" : fanqie.coverSource(bookId)
    placeholderChar: bookNameFirstChar

    property string bookNameFirstChar: (bookName !== "") ? bookName.charAt(0) : "书"
    property string bookName: ""

    MouseArea {
        anchors.fill: parent
        enabled: cover.tapToRefresh && cover.bookId !== ""
        onClicked: fanqie.refreshCover(cover.bookId, cover.coverUrl)
    }

    Connections {
        target: fanqie
        function onCoversUpdated(id) {
            if (id === cover.bookId)
                cover.source = fanqie.coverSource(cover.bookId)
        }
    }
}
