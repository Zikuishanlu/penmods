import QtQuick 2.12
import "ui"
import "pages"

// 插件根：左工具栏 + 每导航独立页面栈，无顶栏
// 导航：书架 / 搜索 / 分类 / 下载 / 历史 / 阅读，每块各自维护一套页面栈，
// 切换导航时恢复各自栈顶页面，互不干扰。
Item {
    id: root
    anchors.fill: parent
    z: 100
    signal backButtonClicked()
    property string pluginName: ""

    // 当前导航下标；阅读导航的栈由 openReader 特殊管理
    property int currentNav: 0
    readonly property int readerNavIndex: 5
    // 阅读器是从哪个导航打开的（-1 = 单独点"阅读"导航打开，无来源）；
    // readerFlowBase = 阅读栈里来源页部分的深度，用来识别"贴着来源页的第一层阅读页"
    property int readerOriginNav: -1
    property int readerFlowBase: 0
    property var navStacks: [stackBookshelf, stackSearch, stackCategories,
                             stackDownloads, stackHistory, stackReader]

    // HOME/宿主关闭信号：阅读会话可能在任意导航下保持打开（从阅读页返回不关会话），
    // 退出时统一把阅读进度落盘
    onBackButtonClicked: {
        fanqie.closeReading()
    }

    // 不透明背景，挡住宿主页面
    Rectangle {
        anchors.fill: parent
        color: Theme.bg
    }

    // 宿主注入的返回：工具栏返回钮 → 栈内有页面则弹栈，否则关闭插件
    NavToolbar {
        id: toolbar
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.left: parent.left

        onNavRequested: switchNav(index, page)
        onBackRequested: back()
    }

    // ---------- 六个导航各自的页面栈 ----------
    PageStack {
        id: stackBookshelf
        pageDir: Qt.resolvedUrl("pages/")
        rootItem: root
        controller: root
        anchors.left: toolbar.right
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.bottom: parent.bottom
    }

    PageStack {
        id: stackSearch
        pageDir: Qt.resolvedUrl("pages/")
        rootItem: root
        controller: root
        anchors.left: toolbar.right
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.bottom: parent.bottom
    }

    PageStack {
        id: stackCategories
        pageDir: Qt.resolvedUrl("pages/")
        rootItem: root
        controller: root
        anchors.left: toolbar.right
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.bottom: parent.bottom
    }

    PageStack {
        id: stackDownloads
        pageDir: Qt.resolvedUrl("pages/")
        rootItem: root
        controller: root
        anchors.left: toolbar.right
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.bottom: parent.bottom
    }

    PageStack {
        id: stackHistory
        pageDir: Qt.resolvedUrl("pages/")
        rootItem: root
        controller: root
        anchors.left: toolbar.right
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.bottom: parent.bottom
    }

    PageStack {
        id: stackReader
        pageDir: Qt.resolvedUrl("pages/")
        rootItem: root
        controller: root
        anchors.left: toolbar.right
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.bottom: parent.bottom
    }

    // ---------- 控制器 ----------
    // 切换到目标导航；目标栈为空则铺根页。阅读导航特殊：栈顶不是阅读页时补一页，
    // 保证点"阅读"永远落在阅读器上（有会话恢复阅读，没会话显示空态）。
    function switchNav(index, page) {
        var s = navStacks[index]
        if (s.depth() === 0)
            s.push(page)
        else if (index === readerNavIndex && s.currentPage !== "ReaderPage")
            s.push("ReaderPage")
        if (index === currentNav) {
            syncNav()   // 首次进入（初始化铺根页）时也要同步一次可见性
            return
        }
        currentNav = index
        syncNav()
    }

    // 打开阅读器（页面经 stack.openReader 调到这里）：
    // 把当前导航的整条栈复制进阅读导航，再压入阅读页，跳到阅读导航。
    // 这样从其它页面打开时阅读页有完整返回链；单独点"阅读"导航打开则只有阅读页本身。
    function openReader(props) {
        if (currentNav === readerNavIndex) {
            // 阅读流程内打开（目录选章等）：不重置来源
            stackReader.push("ReaderPage", props)
            return
        }
        readerOriginNav = currentNav
        readerFlowBase = navStacks[currentNav].depth()
        stackReader.setPages(navStacks[currentNav].pagesCopy())
        stackReader.push("ReaderPage", props)
        currentNav = readerNavIndex
        syncNav()
    }

    // 返回：阅读页贴着来源页时切回来源导航（高亮跟着切），阅读栈与会话保留，
    // 点"阅读"随时回来继续；阅读流程内的阅读页（目录选章后）正常弹栈；
    // 其余情况栈内有页面就弹栈，否则退出插件
    function back() {
        var s = navStacks[currentNav]
        if (s.currentPage === "ReaderPage") {
            if (s.depth() === readerFlowBase + 1) {
                // 第一层阅读页：回到打开阅读器之前的导航
                if (readerOriginNav >= 0 && readerOriginNav !== currentNav) {
                    currentNav = readerOriginNav
                    syncNav()
                    return
                }
                // 单独打开（无来源）：返回即退出插件
                root.backButtonClicked()
                return
            }
            // 目录选章后叠的阅读页：正常弹栈回目录/上一阅读页
            s.pop()
            return
        }
        if (s.depth() > 1)
            s.pop()
        else
            root.backButtonClicked()
    }

    function syncNav() {
        toolbar.currentIndex = currentNav
        for (var i = 0; i < navStacks.length; ++i)
            navStacks[i].visible = (i === currentNav)
    }

    Toast {
        id: toast
        anchors.fill: parent
        z: 950
    }

    ErrorDialog {
        id: errorDialog
        anchors.fill: parent
    }

    Connections {
        target: fanqie
        function onToast(msg) {
            if (msg !== undefined && msg !== "")
                toast.show(msg)
        }
        function onErrorDialog(title, msg) {
            if (msg !== undefined && msg !== "")
                errorDialog.show(title, msg)
        }
        function onTaskFinished(bookId, ok, err) {
            if (!ok && err !== undefined && err !== "")
                toast.show(err)
        }
    }

    Component.onCompleted: {
        switchNav(0, "BookshelfPage")
    }
}
