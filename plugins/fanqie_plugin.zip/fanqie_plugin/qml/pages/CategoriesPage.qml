import QtQuick 2.12
import ".."
import "../ui"

// 分类：仿网页"发现"页，按频道（男频/女频）展示分组分类，点分类进书单
Item {
    id: page

    property var stack: null
    property string _gender: "男频"
    property var _sections: []
    property bool _loading: true
    property bool _failed: false

    // ---------- 顶栏：标题 + 频道切换 ----------
    Item {
        id: header
        height: 26
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right

        Text {
            font.family: Theme.fontFamily
            anchors.left: parent.left
            anchors.leftMargin: 10
            anchors.verticalCenter: parent.verticalCenter
            font.pixelSize: Theme.fontBody
            color: Theme.textDim
            text: "分类"
        }

        Row {
            anchors.right: parent.right
            anchors.rightMargin: 6
            anchors.verticalCenter: parent.verticalCenter
            spacing: 4

            Btn {
                btnWidth: 40; btnHeight: 20
                text: "男频"
                pixelSize: Theme.fontSmall
                fill: page._gender === "男频" ? Theme.accent : Theme.elevated
                textColor: page._gender === "男频" ? "white" : Theme.textDim
                onClicked: page.switchGender("男频")
            }
            Btn {
                btnWidth: 40; btnHeight: 20
                text: "女频"
                pixelSize: Theme.fontSmall
                fill: page._gender === "女频" ? Theme.accent : Theme.elevated
                textColor: page._gender === "女频" ? "white" : Theme.textDim
                onClicked: page.switchGender("女频")
            }
        }
    }

    // ---------- 分类面板：每个分组 = 标题 + 横向滚动标签行 ----------
    ListView {
        id: sectionList
        anchors.top: header.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        spacing: 2
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        model: page._sections

        delegate: Item {
            width: sectionList.width
            height: 46   // 标题 18 + 标签行 26 + 间距

            Text {
                id: titleText
                font.family: Theme.fontFamily
                anchors.left: parent.left
                anchors.leftMargin: 10
                anchors.top: parent.top
                height: 18
                verticalAlignment: Text.AlignVCenter
                font.pixelSize: Theme.fontSmall
                color: Theme.accent
                text: modelData.title
            }

            // 横向滚动标签行
            Flickable {
                anchors.top: titleText.bottom
                anchors.left: parent.left
                anchors.right: parent.right
                height: 26
                clip: true
                contentWidth: chipRow.width
                contentHeight: 26
                boundsBehavior: Flickable.StopAtBounds

                Row {
                    id: chipRow
                    anchors.left: parent.left
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 6

                    Repeater {
                        model: modelData.items
                        delegate: Rectangle {
                            height: 22
                            width: chipText.contentWidth + 16
                            radius: 11
                            color: Theme.surface
                            border.color: Theme.divider
                            border.width: 1
                            scale: chipPress.pressed ? 0.9 : 1.0

                            Behavior on scale {
                                NumberAnimation { duration: 90 }
                            }

                            Text {
                                id: chipText
                                font.family: Theme.fontFamily
                                anchors.centerIn: parent
                                font.pixelSize: Theme.fontSmall
                                color: Theme.text
                                text: modelData.title
                            }

                            MouseArea {
                                id: chipPress
                                anchors.fill: parent
                                onClicked: {
                                    // params 为中立分类参数，原样传给书单页
                                    stack.push("CategoryBooksPage", {
                                        category: modelData.params,
                                        title: modelData.title
                                    })
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 空态：分类为空
    Item {
        anchors.top: header.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        visible: page._sections.length === 0 && !page._loading && !page._failed

        Text {
            font.family: Theme.fontFamily
            anchors.centerIn: parent
            font.pixelSize: Theme.fontBody
            color: Theme.textDim
            text: "暂无分类"
        }
    }

    // 加载失败：点击重试
    Item {
        anchors.fill: parent
        visible: page._failed

        Text {
            font.family: Theme.fontFamily
            anchors.centerIn: parent
            font.pixelSize: Theme.fontBody
            color: Theme.danger
            text: "加载失败，点击重试"

            MouseArea {
                anchors.fill: parent
                onClicked: {
                    page._failed = false
                    page._loading = true
                    fanqie.loadCategories(page._gender)
                }
            }
        }
    }

    // 加载中
    LoadingOverlay {
        anchors.fill: parent
        active: page._loading
        hint: "加载分类…"
    }

    // ---------- 逻辑 ----------
    function switchGender(g) {
        if (g === page._gender)
            return
        page._gender = g
        page._loading = true
        page._failed = false
        fanqie.loadCategories(g)
    }

    Connections {
        target: fanqie
        function onCategoriesLoaded(ok) {
            page._loading = false
            page._failed = !ok
            page._sections = fanqie.categorySections()
        }
    }

    Component.onCompleted: {
        fanqie.loadCategories(page._gender)
    }
}
