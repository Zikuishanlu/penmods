import QtQuick 2.12
import ".."
import "../ui"

// 阅读历史：点击续读，支持长按移除与多选管理
Item {
    id: page

    property var stack: null
    property var selected: ({})
    property bool manageMode: false
    property string _pendingDeleteBook: ""
    property int _pendingDeleteCount: 0

    Item {
        id: header
        height: 20
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right

        Text {
            font.family: Theme.fontFamily
            anchors.left: parent.left
            anchors.leftMargin: 10
            anchors.verticalCenter: parent.verticalCenter
            font.pixelSize: Theme.fontBody
            color: Theme.textDim
            text: manageMode ? "选择记录" : "历史"
        }

        Btn {
            anchors.right: parent.right
            anchors.rightMargin: 6
            anchors.verticalCenter: parent.verticalCenter
            btnWidth: 44; btnHeight: 18
            text: manageMode ? "完成" : "管理"
            fill: "transparent"
            textColor: Theme.accent
            pixelSize: Theme.fontSmall
            onClicked: {
                manageMode = !manageMode
                selected = {}
            }
        }
    }

    ListView {
        id: list
        anchors.top: header.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.leftMargin: 6
        anchors.rightMargin: 6
        anchors.bottomMargin: manageMode ? 38 : 6
        spacing: 4
        clip: true
        model: fanqie.historyModel

        delegate: Rectangle {
            width: list.width
            height: 44
            radius: Theme.radiusSmall
            color: Theme.surface
            border.color: checked ? Theme.accent : "transparent"
            border.width: 1
            scale: press.pressed ? 0.97 : 1.0

            Behavior on scale {
                NumberAnimation { duration: 90 }
            }

            Row {
                anchors.fill: parent
                anchors.margins: 6
                spacing: 8

                CoverImage {
                    bookId: model.bookId
                    bookName: model.bookName
                    displayWidth: 26
                    displayHeight: 32
                    anchors.verticalCenter: parent.verticalCenter
                }

                Column {
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.width - 34 - (page.manageMode ? 22 : 0)
                    spacing: 2

                    Text {
                        font.family: Theme.fontFamily
                        width: parent.width
                        font.pixelSize: Theme.fontBody
                        color: Theme.text
                        elide: Text.ElideRight
                        text: model.bookName
                    }

                    Text {
                        font.family: Theme.fontFamily
                        width: parent.width
                        font.pixelSize: Theme.fontSmall
                        color: Theme.textDim
                        elide: Text.ElideRight
                        text: model.chapterTitle !== ""
                              ? "读到 " + model.chapterTitle
                              : "读到第 " + (model.lastChapter + 1) + " 章"
                    }
                }
            }

            // 多选勾选圈
            Rectangle {
                visible: page.manageMode
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                anchors.rightMargin: 8
                width: 16
                height: 16
                radius: 8
                color: checked ? Theme.accent : "transparent"
                border.color: checked ? Theme.accent : Theme.textFaint
                border.width: 1

                Text {
                    font.family: Theme.fontFamily
                    anchors.centerIn: parent
                    font.pixelSize: 10
                    color: "white"
                    text: "✓"
                    visible: checked
                }
            }

            readonly property bool checked: page.selected[model.bookId] === true

            MouseArea {
                id: press
                anchors.fill: parent
                onPressAndHold: {
                    if (page.manageMode)
                        return
                    actionMenu.title = model.bookName
                    actionMenu.actions = [
                        { label: "继续阅读" },
                        { label: "从历史移除", color: Theme.danger }
                    ]
                    actionMenu._bookId = model.bookId
                    actionMenu._bookName = model.bookName
                    actionMenu._author = model.author
                    actionMenu._coverUrl = model.coverUrl
                    actionMenu._chapter = model.lastChapter
                    actionMenu._fraction = model.progress !== undefined ? model.progress : 0
                    actionMenu.show()
                }
                onClicked: {
                    if (page.manageMode) {
                        var sel = page.selected
                        if (sel[model.bookId] === true)
                            delete sel[model.bookId]
                        else
                            sel[model.bookId] = true
                        var copy = {}
                        for (var k in sel)
                            copy[k] = sel[k]
                        page.selected = copy
                        return
                    }
                    // 先开详情页，续读位置由历史记录带过去
                    stack.push("BookDetailPage", {
                        bookId: model.bookId,
                        bookName: model.bookName,
                        author: model.author,
                        coverUrl: model.coverUrl
                    })
                }
            }
        }

        // 空态
        footer: Item {
            width: list.width
            height: 0
        }
    }

    // 空态覆盖层
    Item {
        anchors.top: header.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        visible: list.count === 0

        Column {
            anchors.centerIn: parent
            spacing: 6
            Text {
                font.family: Theme.fontFamily
                anchors.horizontalCenter: parent.horizontalCenter
                font.pixelSize: Theme.fontBody
                color: Theme.textDim
                text: "还没有阅读记录"
            }
            Text {
                font.family: Theme.fontFamily
                anchors.horizontalCenter: parent.horizontalCenter
                font.pixelSize: Theme.fontSmall
                color: Theme.textFaint
                text: "看过的书会出现在这里"
            }
        }
    }

    // ---------- 多选操作条 ----------
    Rectangle {
        visible: page.manageMode
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        height: 34
        color: Theme.elevated

        Row {
            anchors.left: parent.left
            anchors.leftMargin: 8
            anchors.verticalCenter: parent.verticalCenter
            spacing: 10

            Btn {
                btnWidth: 40; btnHeight: 22
                text: "全选"
                fill: Theme.elevated
                textColor: Theme.text
                pixelSize: Theme.fontSmall
                onClicked: {
                    var sel = {}
                    var m = fanqie.historyModel
                    for (var i = 0; i < m.rowCount(); ++i)
                        sel[m.get(i).bookId] = true
                    page.selected = sel
                }
            }
        }

        Text {
            font.family: Theme.fontFamily
            anchors.right: removeBtn.left
            anchors.rightMargin: 8
            anchors.verticalCenter: parent.verticalCenter
            font.pixelSize: Theme.fontSmall
            color: Theme.textDim
            text: "已选 " + countSelected() + " 条"
        }

        Btn {
            id: removeBtn
            anchors.right: parent.right
            anchors.rightMargin: 8
            anchors.verticalCenter: parent.verticalCenter
            btnWidth: 76; btnHeight: 26
            text: "移除所选"
            fill: Theme.danger
            onClicked: {
                var n = countSelected()
                if (n === 0)
                    return
                page._pendingDeleteBook = ""
                page._pendingDeleteCount = n
                confirmDialog.tipText = "从历史移除所选 " + n + " 条？"
                confirmDialog.confirmText = "移除"
                confirmDialog.show()
            }
        }
    }

    function countSelected() {
        var n = 0
        for (var k in page.selected)
            if (page.selected[k])
                ++n
        return n
    }

    function openBook(bookId, name, author, coverUrl, chapter, fraction) {
        fanqie.openBook(bookId, name, author, coverUrl, chapter, fraction)
        stack.openReader({ initialChapter: chapter, initialFraction: fraction })
    }

    ActionMenu {
        id: actionMenu
        property string _bookId: ""
        property string _bookName: ""
        property string _author: ""
        property string _coverUrl: ""
        property int _chapter: 0
        property real _fraction: 0
        onActionClicked: {
            if (index === 0) {
                openBook(_bookId, _bookName, _author, _coverUrl, _chapter, _fraction)
            } else if (index === 1) {
                page._pendingDeleteBook = _bookId
                page._pendingDeleteCount = 1
                confirmDialog.tipText = "从历史移除《" + actionMenu.title + "》？"
                confirmDialog.confirmText = "移除"
                confirmDialog.show()
            }
        }
    }

    ConfirmDialog {
        id: confirmDialog
        onConfirmed: {
            if (page._pendingDeleteBook !== "") {
                fanqie.removeHistory(page._pendingDeleteBook)
                page._pendingDeleteBook = ""
            } else {
                for (var k in page.selected)
                    if (page.selected[k])
                        fanqie.removeHistory(k)
                page.selected = {}
                page.manageMode = false
            }
        }
    }
}
