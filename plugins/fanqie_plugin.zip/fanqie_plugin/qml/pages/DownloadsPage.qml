import QtQuick 2.12
import ".."
import "../ui"

// 下载：任务列表，运行中显示进度，可取消；完成后可删除记录
Item {
    id: page

    property var stack: null

    Item {
        id: header
        height: 20
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right

        Text {
            font.family: Theme.fontFamily
            anchors.left: parent.left
            anchors.leftMargin: 10
            anchors.verticalCenter: parent.verticalCenter
            font.pixelSize: Theme.fontBody
            color: Theme.textDim
            text: "下载"
        }
    }

    ListView {
        id: taskList
        anchors.top: header.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.margins: 6
        spacing: 4
        clip: true
        model: fanqie.downloadModel

        delegate: Rectangle {
            width: taskList.width
            height: 44
            radius: Theme.radiusSmall
            color: Theme.surface

            Column {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                anchors.leftMargin: 8
                anchors.rightMargin: 82
                spacing: 4

                Row {
                    width: parent.width
                    spacing: 6

                    Text {
                        font.family: Theme.fontFamily
                        width: parent.width - 66
                        font.pixelSize: Theme.fontBody
                        color: Theme.text
                        elide: Text.ElideRight
                        text: model.bookName
                    }

                    Text {
                        font.family: Theme.fontFamily
                        width: 60
                        font.pixelSize: Theme.fontSmall
                        color: Theme.textDim
                        horizontalAlignment: Text.AlignRight
                        text: model.running ? model.done + "/" + model.total : ""
                    }
                }

                // 进度条
                Rectangle {
                    visible: model.running
                    width: parent.width
                    height: 3
                    radius: 1.5
                    color: Theme.divider

                    Rectangle {
                        width: model.total > 0 ? parent.width * model.done / model.total : 0
                        height: parent.height
                        radius: 1.5
                        color: Theme.success
                    }
                }

                Text {
                    font.family: Theme.fontFamily
                    visible: !model.running && !model.paused
                    width: parent.width
                    font.pixelSize: Theme.fontSmall
                    color: model.error === "" ? Theme.textDim : Theme.danger
                    elide: Text.ElideRight
                    text: model.error === ""
                          ? "已完成 " + model.done + " 章"
                          : model.error
                }

                Text {
                    font.family: Theme.fontFamily
                    visible: model.paused
                    width: parent.width
                    font.pixelSize: Theme.fontSmall
                    color: Theme.textDim
                    elide: Text.ElideRight
                    text: "已暂停 · " + model.done + "/" + model.total + " 章"
                }
            }

            // 右侧：暂停/取消 / 继续 / 删除
            Row {
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                anchors.rightMargin: 6
                spacing: 4

                Btn {
                    visible: model.running
                    btnWidth: 36; btnHeight: 24
                    text: "暂停"
                    fill: Theme.elevated
                    textColor: Theme.text
                    pixelSize: Theme.fontSmall
                    onClicked: fanqie.pauseDownload(model.bookId)
                }
                Btn {
                    visible: model.running
                    btnWidth: 36; btnHeight: 24
                    text: "取消"
                    fill: Theme.elevated
                    textColor: Theme.text
                    pixelSize: Theme.fontSmall
                    // 取消保留已下章节，书会留在书架，可从详情续传
                    onClicked: fanqie.cancelDownload(model.bookId)
                }
                Btn {
                    visible: model.paused
                    btnWidth: 36; btnHeight: 24
                    text: "继续"
                    fill: Theme.accentDim
                    textColor: "white"
                    pixelSize: Theme.fontSmall
                    onClicked: fanqie.resumeDownload(model.bookId)
                }
                Btn {
                    // 结束或已暂停的任务都能删记录（暂停的任务不占资源，删了就是放弃）
                    visible: !model.running
                    btnWidth: 36; btnHeight: 24
                    text: "删除"
                    fill: Theme.divider
                    textColor: Theme.textFaint
                    pixelSize: Theme.fontSmall
                    onClicked: fanqie.removeDownloadTask(model.bookId)
                }
            }
        }

        // 空态
        footer: Item {
            width: taskList.width
            height: 0
        }
    }

    // 空态覆盖层
    Item {
        anchors.top: header.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        visible: taskList.count === 0

        Column {
            anchors.centerIn: parent
            spacing: 6
            Text {
                font.family: Theme.fontFamily
                anchors.horizontalCenter: parent.horizontalCenter
                font.pixelSize: Theme.fontBody
                color: Theme.textDim
                text: "没有下载任务"
            }
            Text {
                font.family: Theme.fontFamily
                anchors.horizontalCenter: parent.horizontalCenter
                font.pixelSize: Theme.fontSmall
                color: Theme.textFaint
                text: "在书籍详情页点击下载"
            }
        }
    }
}
