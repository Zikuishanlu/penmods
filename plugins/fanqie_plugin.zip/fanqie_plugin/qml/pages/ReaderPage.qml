import QtQuick 2.12
import ".."
import "../ui"

// 阅读器：一次一章，章节头/尾带切换按钮，右侧细进度条滑块，滚动节流上报进度
Item {
    id: page

    property var stack: null
    property int initialChapter: 0
    property real initialFraction: 0   // 上次读到的本章进度（0~1），仅首次进入生效
    property int currentIndex: -1
    property int _chapterCount: 0
    property string _title: ""
    property string _text: ""
    property bool _loading: false
    property string _error: ""
    property bool controlsVisible: false
    property real _fraction: 0
    property bool _restored: false     // 本次会话是否已恢复过位置（切章后不再恢复）
    property bool _empty: false        // 没有打开的书籍：显示空态

    property var fontSizes: [12, 14, 16, 18]
    property int fontSizeIndex: 1
    readonly property int fontSize: fontSizes[fontSizeIndex]

    readonly property bool _hasPrev: currentIndex > 0
    // 章节数未知（目录还没回来）时也允许点下一章，点下去会重试拉目录
    readonly property bool _hasNext: currentIndex >= 0
                                     && (_chapterCount === 0 || currentIndex + 1 < _chapterCount)

    // ---------- 正文滚动区（右缘留给滑块） ----------
    Flickable {
        id: flick
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: sliderArea.left
        anchors.bottom: parent.bottom
        contentHeight: textCol.height
        clip: true
        boundsBehavior: Flickable.StopAtBounds

        Column {
            id: textCol
            width: parent.width - 10
            anchors.horizontalCenter: parent.horizontalCenter
            spacing: 8

            // 顶部留空
            Item { width: 1; height: 10 }

            // 章节切换（顶）
            Row {
                anchors.horizontalCenter: parent.horizontalCenter
                spacing: 10
                ControlBtn { text: "上一章"; enabled: page._hasPrev; onClicked: page.goTo(page.currentIndex - 1) }
                ControlBtn { text: "下一章"; enabled: page._hasNext; onClicked: page.goTo(page.currentIndex + 1) }
            }

            // 章节号
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                font.family: Theme.fontFamily
                font.pixelSize: Theme.fontSmall
                color: Theme.textFaint
                text: page.currentIndex >= 0 ? "第 " + (page.currentIndex + 1) + " 章" : ""
            }

            // 章节名
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                width: parent.width
                font.family: Theme.fontFamily
                font.pixelSize: Theme.fontBody
                color: Theme.textDim
                wrapMode: Text.Wrap
                horizontalAlignment: Text.AlignHCenter
                text: page._title
            }

            // 正文
            Text {
                id: bodyText
                width: parent.width
                font.family: Theme.fontFamily
                font.pixelSize: page.fontSize
                color: Theme.text
                wrapMode: Text.Wrap
                lineHeight: 1.6
                text: page._error !== "" ? page._error : page._text

                // 点按正文切换控制条
                TapHandler {
                    onTapped: page.controlsVisible = !page.controlsVisible
                }
            }

            // 章节切换（底）
            Item { width: 1; height: 4 }
            Row {
                anchors.horizontalCenter: parent.horizontalCenter
                spacing: 10
                ControlBtn { text: "上一章"; enabled: page._hasPrev; onClicked: page.goTo(page.currentIndex - 1) }
                ControlBtn { text: "下一章"; enabled: page._hasNext; onClicked: page.goTo(page.currentIndex + 1) }
            }
            Item { width: 1; height: 10 }

            // 加载失败重试（行内，不挡章节按钮）
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                visible: page._error !== "" && !page._loading
                font.family: Theme.fontFamily
                font.pixelSize: Theme.fontBody
                color: Theme.danger
                text: "加载失败，点击重试"

                MouseArea {
                    anchors.fill: parent
                    onClicked: {
                        page._error = ""
                        fanqie.loadChapter(page.currentIndex)
                    }
                }
            }
        }

        onContentYChanged: {
            if (flick.contentHeight > flick.height) {
                page._fraction = flick.contentY / (flick.contentHeight - flick.height)
                progressTimer.restart()
            } else {
                page._fraction = 1
            }
        }
    }

    // ---------- 右侧细进度条 ----------
    Item {
        id: sliderArea
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.right: parent.right
        width: 14

        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.top: parent.top
            anchors.bottom: parent.bottom
            width: 3
            radius: 1.5
            color: Theme.divider
        }

        Rectangle {
            id: sliderHandle
            anchors.horizontalCenter: parent.horizontalCenter
            width: 3
            height: 16
            radius: 1.5
            color: Theme.accent
            y: page._fraction * (sliderArea.height - height)
        }

        MouseArea {
            anchors.fill: parent
            onPressed: seek(mouse.y)
            onPositionChanged: seek(mouse.y)

            function seek(y) {
                if (flick.contentHeight <= flick.height)
                    return
                var range = sliderArea.height - sliderHandle.height
                var f = Math.max(0, Math.min(1, (y - sliderHandle.height / 2) / range))
                page._fraction = f
                flick.contentY = f * (flick.contentHeight - flick.height)
                page.report()
            }
        }
    }

    // ---------- 空态：还没打开任何书籍 ----------
    Rectangle {
        anchors.fill: parent
        visible: page._empty
        color: Theme.bg
        z: 20   // 压过控制条，挡住点按

        MouseArea {
            anchors.fill: parent   // 吞掉点击，避免唤出底部的控制条
        }

        Column {
            anchors.centerIn: parent
            spacing: 6
            Text {
                font.family: Theme.fontFamily
                anchors.horizontalCenter: parent.horizontalCenter
                font.pixelSize: Theme.fontBody
                color: Theme.textDim
                text: "还没打开任何书籍"
            }
            Text {
                font.family: Theme.fontFamily
                anchors.horizontalCenter: parent.horizontalCenter
                font.pixelSize: Theme.fontSmall
                color: Theme.textFaint
                text: "去书架或搜索页打开一本书吧"
            }
        }
    }

    // ---------- 加载中 ----------
    Rectangle {
        anchors.fill: parent
        visible: page._loading
        color: Theme.bg

        Column {
            anchors.centerIn: parent
            spacing: 6
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                font.family: Theme.fontFamily
                font.pixelSize: Theme.fontBody
                color: Theme.textDim
                text: "加载中…"
            }
        }
    }

    // ---------- 出错重试（改为正文内行内文本，见正文区底部） ----------

    // ---------- 控制条（点按正文唤出） ----------
    Rectangle {
        id: controlBar
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        height: 30
        color: Theme.elevated
        visible: page.controlsVisible
        opacity: 0.97

        Row {
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
            anchors.leftMargin: 4
            anchors.rightMargin: 4
            spacing: 2

            ControlBtn { btnHeight: 22; text: "返回"; onClicked: page.goBack() }
            ControlBtn { btnHeight: 22; text: "目录"; onClicked: page.goToc() }

            Text {
                width: 48
                height: 22
                font.family: Theme.fontFamily
                font.pixelSize: Theme.fontSmall
                color: Theme.textDim
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
                text: page._chapterCount > 0
                      ? (page.currentIndex + 1) + "/" + page._chapterCount
                      : ""
            }

            ControlBtn { btnHeight: 22; text: "A−"; onClicked: page.fontSizeIndex = Math.max(0, page.fontSizeIndex - 1) }
            ControlBtn { btnHeight: 22; text: "A+"; onClicked: page.fontSizeIndex = Math.min(page.fontSizes.length - 1, page.fontSizeIndex + 1) }
        }
    }

    // ---------- 逻辑 ----------
    function goTo(index) {
        // 切章：取消还没触发的"恢复位置"，进度只认当前章
        restoreTimer.stop()
        page._error = ""
        page._loading = true
        page._text = ""
        page._title = ""
        page.currentIndex = index
        page._fraction = 0
        fanqie.chapterModel.currentIndex = index
        fanqie.loadChapter(index)
    }

    function goBack() {
        // 与工具栏返回一致：阅读页贴着来源页时切回来源导航（会话保留可快速续读），
        // 单独打开时退出插件；阅读流程内（目录选章后）正常弹栈
        stack.back()
    }

    function goToc() {
        // 打开目录：不关会话，从目录返回时继续当前章节和位置
        var s = fanqie.currentReading()
        if (s.bookId === undefined || s.bookId === "")
            return
        stack.push("ChapterListPage", {
            bookId: s.bookId,
            bookName: s.bookName !== undefined ? s.bookName : "",
            author: s.author !== undefined ? s.author : "",
            coverUrl: s.coverUrl !== undefined ? s.coverUrl : ""
        })
    }

    function report() {
        var frac = 0
        if (flick.contentHeight > flick.height)
            frac = flick.contentY / (flick.contentHeight - flick.height)
        else
            frac = 1
        page._fraction = frac
        fanqie.reportProgress(page.currentIndex, frac)
    }

    Timer {
        id: progressTimer
        interval: 1500
        onTriggered: page.report()
    }

    // 每 15 分钟把当前章的阅读位置落盘一次（退出时另有 closeReading 兜底）
    Timer {
        id: saveTimer
        interval: 15 * 60 * 1000
        repeat: true
        onTriggered: fanqie.persistReading()
    }

    // 首次进入保存的章节时，等正文布局完成后恢复上次滚动位置
    Timer {
        id: restoreTimer
        interval: 50
        repeat: false
        onTriggered: {
            if (flick.contentHeight > flick.height) {
                flick.contentY = page.initialFraction * (flick.contentHeight - flick.height)
                page.report()
            }
        }
    }

    Connections {
        target: fanqie
        function onChapterReady(index, title, text, err) {
            if (index !== page.currentIndex)
                return
            page._loading = false
            page._error = err
            page._title = title
            page._text = text
            flick.contentY = 0
            page.report()
            // 只对进入时的那一章恢复位置；一旦切章，本次会话就不再恢复（进度只认当前章）
            if (!page._restored && index === page.initialChapter && page.initialFraction > 0) {
                page._restored = true
                restoreTimer.start()
            }
        }
        function onBookOpened(bookId, count) {
            page._chapterCount = count
        }
    }

    Component.onCompleted: {
        // 会话优先：从目录返回时继续当前章节和位置；首次进入时会话刚由 openBook
        // 建立（章节=进入章、位置=续读位置），与会话一致
        var s = fanqie.currentReading()
        // 没打开任何书籍（单独点"阅读"导航进来）：显示空态
        if (s.bookId === undefined || s.bookId === "") {
            page._empty = true
            return
        }
        var startChapter = page.initialChapter
        var startFraction = page.initialFraction
        if (s.chapterIndex >= 0) {
            startChapter = s.chapterIndex
            startFraction = s.fraction !== undefined ? s.fraction : 0
            if (s.chapterCount !== undefined && s.chapterCount > 0)
                page._chapterCount = s.chapterCount
        }
        page.initialChapter = startChapter
        page.initialFraction = startFraction
        page.currentIndex = startChapter
        fanqie.chapterModel.currentIndex = startChapter
        page.goTo(startChapter)
    }
}
