import QtQuick 2.12
import ".."
import "../ui"

// 书架：已下载的书，支持长按删除与多选管理
Item {
    id: page

    property var stack: null
    property var selected: ({})
    property bool manageMode: false
    property string _pendingDeleteBook: ""   // 单删目标，空串表示多删
    property int _pendingDeleteCount: 0

    // ---------- 头部 ----------
    Item {
        id: header
        height: 20
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right

        Text {
            font.family: Theme.fontFamily
            anchors.left: parent.left
            anchors.leftMargin: 10
            anchors.verticalCenter: parent.verticalCenter
            font.pixelSize: Theme.fontBody
            color: Theme.textDim
            text: manageMode ? "选择书籍" : "书架"
        }

        Btn {
            anchors.right: parent.right
            anchors.rightMargin: 6
            anchors.verticalCenter: parent.verticalCenter
            btnWidth: 44; btnHeight: 18
            text: manageMode ? "完成" : "管理"
            fill: "transparent"
            textColor: Theme.accent
            pixelSize: Theme.fontSmall
            onClicked: {
                manageMode = !manageMode
                selected = {}
            }
        }
    }

    // ---------- 书格 ----------
    GridView {
        id: grid
        anchors.top: header.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.leftMargin: 6
        anchors.rightMargin: 6
        anchors.bottomMargin: manageMode ? 38 : 6
        cellWidth: grid.width / 2
        cellHeight: 80
        clip: true
        model: fanqie.bookshelfModel

        delegate: Item {
            width: grid.cellWidth
            height: grid.cellHeight
            scale: press.pressed ? 0.96 : 1.0

            Behavior on scale {
                NumberAnimation { duration: 90 }
            }

            Rectangle {
                id: card
                anchors.fill: parent
                anchors.margins: 3
                radius: Theme.radiusSmall
                color: Theme.surface
                border.color: checked ? Theme.accent : "transparent"
                border.width: 1

                Row {
                    anchors.fill: parent
                    anchors.margins: 6
                    spacing: 6

                    CoverImage {
                        bookId: model.bookId
                        bookName: model.bookName
                        displayWidth: 38
                        displayHeight: 50
                        anchors.verticalCenter: parent.verticalCenter
                    }

                    Column {
                        anchors.verticalCenter: parent.verticalCenter
                        width: parent.width - 44
                        spacing: 3

                        Text {
                            font.family: Theme.fontFamily
                            width: parent.width
                            font.pixelSize: Theme.fontBody
                            color: Theme.text
                            elide: Text.ElideRight
                            maximumLineCount: 2
                            wrapMode: Text.Wrap
                            text: model.bookName
                        }

                        Text {
                            font.family: Theme.fontFamily
                            width: parent.width
                            font.pixelSize: Theme.fontSmall
                            color: model.complete ? Theme.textDim : Theme.accent
                            elide: Text.ElideRight
                            text: !model.complete ? "已下 " + model.chapterCount + " 章 · 未完成"
                                 : (model.lastChapter > 0
                                    ? "读到第 " + (model.lastChapter + 1) + " 章"
                                    : "共 " + model.chapterCount + " 章")
                        }
                    }
                }

                // 多选勾选圈
                Rectangle {
                    visible: page.manageMode
                    anchors.top: parent.top
                    anchors.right: parent.right
                    anchors.margins: 4
                    width: 16
                    height: 16
                    radius: 8
                    color: checked ? Theme.accent : "transparent"
                    border.color: checked ? Theme.accent : Theme.textFaint
                    border.width: 1

                    Text {
                        font.family: Theme.fontFamily
                        anchors.centerIn: parent
                        font.pixelSize: 10
                        color: "white"
                        text: "✓"
                        visible: checked
                    }
                }
            }

            readonly property bool checked: page.selected[model.bookId] === true

            MouseArea {
                id: press
                anchors.fill: parent
                onPressAndHold: {
                    if (page.manageMode)
                        return
                    actionMenu.title = model.bookName
                    actionMenu.actions = [
                        { label: "继续阅读" },
                        { label: "删除", color: Theme.danger }
                    ]
                    actionMenu._bookId = model.bookId
                    actionMenu._bookName = model.bookName
                    actionMenu._author = model.author
                    actionMenu._coverUrl = model.coverUrl
                    actionMenu._chapter = model.lastChapter
                    actionMenu._fraction = model.progress !== undefined ? model.progress : 0
                    actionMenu.show()
                }
                onClicked: {
                    if (page.manageMode) {
                        var sel = page.selected
                        if (sel[model.bookId] === true)
                            delete sel[model.bookId]
                        else
                            sel[model.bookId] = true
                        var copy = {}
                        for (var k in sel)
                            copy[k] = sel[k]
                        page.selected = copy
                        return
                    }
                    // 先开详情页，进度在详情页里可续读
                    stack.push("BookDetailPage", {
                        bookId: model.bookId,
                        bookName: model.bookName,
                        author: model.author,
                        coverUrl: model.coverUrl
                    })
                }
            }
        }

        // 空态
        footer: Item {
            width: grid.width
            height: 0
        }
    }

    // 空态覆盖层（GridView 空模型时 footer 不显示，用覆盖层兜底）
    Item {
        anchors.top: header.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        visible: grid.count === 0

        Column {
            anchors.centerIn: parent
            spacing: 6
            Text {
                font.family: Theme.fontFamily
                anchors.horizontalCenter: parent.horizontalCenter
                font.pixelSize: Theme.fontBody
                color: Theme.textDim
                text: "书架空空如也"
            }
            Text {
                font.family: Theme.fontFamily
                anchors.horizontalCenter: parent.horizontalCenter
                font.pixelSize: Theme.fontSmall
                color: Theme.textFaint
                text: "去搜索一本书下载吧"
            }
        }
    }

    // ---------- 多选操作条 ----------
    Rectangle {
        visible: page.manageMode
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        height: 34
        color: Theme.elevated

        Row {
            anchors.left: parent.left
            anchors.leftMargin: 8
            anchors.verticalCenter: parent.verticalCenter
            spacing: 10

            Btn {
                btnWidth: 40; btnHeight: 22
                text: "全选"
                fill: Theme.elevated
                textColor: Theme.text
                pixelSize: Theme.fontSmall
                onClicked: {
                    var sel = {}
                    var m = fanqie.bookshelfModel
                    for (var i = 0; i < m.rowCount(); ++i)
                        sel[m.get(i).bookId] = true
                    page.selected = sel
                }
            }
        }

        Text {
            font.family: Theme.fontFamily
            anchors.right: deleteBtn.left
            anchors.rightMargin: 8
            anchors.verticalCenter: parent.verticalCenter
            font.pixelSize: Theme.fontSmall
            color: Theme.textDim
            text: "已选 " + countSelected() + " 本"
        }

        Btn {
            id: deleteBtn
            anchors.right: parent.right
            anchors.rightMargin: 8
            anchors.verticalCenter: parent.verticalCenter
            btnWidth: 76; btnHeight: 26
            text: "删除所选"
            fill: Theme.danger
            onClicked: {
                var n = countSelected()
                if (n === 0)
                    return
                page._pendingDeleteBook = ""
                page._pendingDeleteCount = n
                confirmDialog.tipText = "删除所选 " + n + " 本书？\n下载内容将一并删除。"
                confirmDialog.confirmText = "删除"
                confirmDialog.show()
            }
        }
    }

    function countSelected() {
        var n = 0
        for (var k in page.selected)
            if (page.selected[k])
                ++n
        return n
    }

    function openBook(bookId, name, author, coverUrl, chapter, fraction) {
        fanqie.openBook(bookId, name, author, coverUrl, chapter, fraction)
        stack.openReader({ initialChapter: chapter, initialFraction: fraction })
    }

    ActionMenu {
        id: actionMenu
        property string _bookId: ""
        property string _bookName: ""
        property string _author: ""
        property string _coverUrl: ""
        property int _chapter: 0
        property real _fraction: 0
        onActionClicked: {
            if (index === 0) {
                openBook(_bookId, _bookName, _author, _coverUrl, _chapter, _fraction)
            } else if (index === 1) {
                page._pendingDeleteBook = _bookId
                page._pendingDeleteCount = 1
                confirmDialog.tipText = "删除《" + actionMenu.title + "》？\n本地下载内容将一并删除。"
                confirmDialog.confirmText = "删除"
                confirmDialog.show()
            }
        }
    }

    ConfirmDialog {
        id: confirmDialog
        onConfirmed: {
            if (page._pendingDeleteBook !== "") {
                fanqie.removeBook(page._pendingDeleteBook)
                page._pendingDeleteBook = ""
            } else {
                for (var k in page.selected)
                    if (page.selected[k])
                        fanqie.removeBook(k)
                page.selected = {}
                page.manageMode = false
            }
        }
    }
}
