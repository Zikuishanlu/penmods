import QtQuick 2.12
import ".."
import "../ui"

// 书籍详情：元信息 + 阅读/下载/目录
Item {
    id: page

    property var stack: null
    property string bookId: ""
    property string bookName: ""
    property string author: ""
    property string coverUrl: ""

    property var _meta: ({})
    property var _tags: []
    property var _shelfEntry: ({})
    property bool downloaded: false
    property bool downloadedComplete: false
    property bool downloading: false
    property bool downloadPaused: false
    property int failedCount: 0
    property int continueChapter: 0
    property real continueFraction: 0   // 续读章节内的滚动位置（0~1）
    property bool _detailLoading: true
    property bool _detailFailed: false

    function refreshShelf() {
        _shelfEntry = fanqie.bookEntry(bookId)
        downloaded = _shelfEntry.bookId !== undefined
        downloadedComplete = downloaded && _shelfEntry.complete !== false
        downloading = fanqie.isDownloading(bookId)
        downloadPaused = fanqie.isDownloadPaused(bookId)
        // 失败标记只在任务结束（下载/重试完成）时变化，运行中不必每次重读磁盘
        if (!downloading)
            failedCount = fanqie.failedChapterCount(bookId)
        // 续读位置：书架优先，其次历史，都没有从第 1 章；进度跟着章节一起取
        var h = fanqie.historyEntry(bookId)
        if (downloaded && _shelfEntry.lastChapter !== undefined) {
            continueChapter = _shelfEntry.lastChapter
            continueFraction = _shelfEntry.progress !== undefined ? _shelfEntry.progress : 0
        } else if (h.bookId !== undefined && h.lastChapter !== undefined) {
            continueChapter = h.lastChapter
            continueFraction = h.progress !== undefined ? h.progress : 0
        } else {
            continueChapter = 0
            continueFraction = 0
        }
    }

    onBookIdChanged: {
        fanqie.loadBookDetail(bookId)
        refreshShelf()
        _detailLoading = true
        _detailFailed = false
        abstractText.expanded = false
    }

    Component.onCompleted: {
        refreshShelf()
        // 缓存命中就直接显示；meta 不完整（没简介）不算命中，照常走网络补全
        var cached = fanqie.cachedBookDetail(bookId)
        if (cached.bookId !== undefined && cached.abstract !== undefined
                && cached.abstract !== "") {
            _meta = cached
            computeTags()
            _detailLoading = false
        }
    }

    Flickable {
        anchors.fill: parent
        contentHeight: contentCol.height
        clip: true
        boundsBehavior: Flickable.StopAtBounds

        Column {
            id: contentCol
            width: parent.width - 12
            anchors.horizontalCenter: parent.horizontalCenter
            spacing: 6

            // 顶部留白
            Item { width: 1; height: 8 }

            // 顶部信息
            Row {
                width: parent.width
                height: 84
                spacing: 10

                CoverImage {
                    anchors.topMargin: 2
                    bookId: page.bookId
                    bookName: page.bookName
                    coverUrl: _meta.coverUrl !== undefined ? _meta.coverUrl : page.coverUrl
                    tapToRefresh: true
                    displayWidth: 54
                    displayHeight: 74
                }

                Column {
                    width: parent.width - 64
                    height: parent.height
                    spacing: 3

                    Text {
                        font.family: Theme.fontFamily
                        width: parent.width
                        font.pixelSize: Theme.fontTitle
                        color: Theme.text
                        wrapMode: Text.Wrap
                        maximumLineCount: 2
                        elide: Text.ElideRight
                        text: _meta.bookName !== undefined ? _meta.bookName : page.bookName
                    }

                    Text {
                        font.family: Theme.fontFamily
                        width: parent.width
                        font.pixelSize: Theme.fontSmall
                        color: Theme.textDim
                        elide: Text.ElideRight
                        text: (_meta.author !== undefined ? _meta.author : page.author)
                              + (_meta.wordNumber !== undefined && _meta.wordNumber > 0
                                 ? " · " + Math.round(_meta.wordNumber / 10000) + " 万字" : "")
                    }

                    // 分类标签（最多 4 个）
                    Flow {
                        width: parent.width
                        spacing: 4
                        visible: page._tags.length > 0

                        Repeater {
                            model: page._tags
                            delegate: Rectangle {
                                height: 15
                                width: tagText.contentWidth + 10
                                radius: 7
                                color: Theme.surface
                                border.color: Theme.divider
                                border.width: 1

                                Text {
                                    font.family: Theme.fontFamily
                                    id: tagText
                                    anchors.centerIn: parent
                                    font.pixelSize: 9
                                    color: Theme.textFaint
                                    text: modelData
                                }
                            }
                        }
                    }
                }
            }

            // 简介：点击在折叠（3 行）/全部展开之间切换
            Text {
                id: abstractText
                font.family: Theme.fontFamily
                width: parent.width - 12
                anchors.horizontalCenter: parent.horizontalCenter
                font.pixelSize: Theme.fontSmall
                color: Theme.textDim
                wrapMode: Text.Wrap
                maximumLineCount: abstractText.expanded ? 9999 : 3
                elide: Text.ElideRight
                lineHeight: 1.4
                text: _meta.abstract !== undefined ? _meta.abstract : ""

                property bool expanded: false

                MouseArea {
                    anchors.fill: parent
                    // 只在真有内容可切换时才拦截点击（简介为空/没截断时不响应）
                    enabled: abstractText.truncated || abstractText.expanded
                    onClicked: abstractText.expanded = !abstractText.expanded
                }
            }

            // 操作条
            Row {
                anchors.horizontalCenter: parent.horizontalCenter
                spacing: 8
                height: 32

                Btn {
                    btnWidth: 84
                    btnHeight: 30
                    text: page.downloaded || page.continueChapter > 0 ? "继续阅读" : "开始阅读"
                    fill: Theme.accent
                    // 没下完也允许看：已下章节走本地，其余走网络
                    onClicked: openReader()
                }

                Btn {
                    btnWidth: 68
                    btnHeight: 30
                    text: page.downloading ? "暂停"
                         : page.downloadPaused ? "继续"
                         : page.downloaded ? (page.downloadedComplete ? "已下载" : "继续下载")
                         : "下载"
                    fill: page.downloadedComplete ? Theme.elevated : Theme.accentDim
                    textColor: page.downloadedComplete ? Theme.success : "white"
                    onClicked: {
                        if (page.downloading)
                            fanqie.pauseDownload(bookId)
                        else if (page.downloadPaused)
                            fanqie.resumeDownload(bookId)
                        else if (!page.downloadedComplete) {
                            var name = _meta.bookName !== undefined && _meta.bookName !== ""
                                       ? _meta.bookName : page.bookName
                            fanqie.downloadBook(bookId, name)
                        }
                    }
                }

                Btn {
                    btnWidth: 68
                    btnHeight: 30
                    text: "目录"
                    fill: Theme.elevated
                    textColor: Theme.text
                    onClicked: {
                        stack.push("ChapterListPage", {
                            bookId: page.bookId,
                            bookName: _meta.bookName !== undefined ? _meta.bookName : page.bookName,
                            author: _meta.author !== undefined ? _meta.author : page.author,
                            coverUrl: _meta.coverUrl !== undefined ? _meta.coverUrl : page.coverUrl
                        })
                    }
                }
            }

            // 失败章节统一重试：整本失败章节一次全进下载队列
            Btn {
                anchors.horizontalCenter: parent.horizontalCenter
                visible: page.failedCount > 0
                btnWidth: 160
                btnHeight: 28
                text: "重试失败章节（" + page.failedCount + "）"
                fill: Theme.accentDim
                textColor: "white"
                onClicked: {
                    var name = _meta.bookName !== undefined && _meta.bookName !== ""
                               ? _meta.bookName : page.bookName
                    fanqie.retryFailedChapters(bookId, name)
                }
            }
        }
    }

    // 从 meta 里拆分类标签：优先 tags（逗号分隔），没有就用 category
    function computeTags() {
        var raw = (_meta.tags !== undefined && _meta.tags !== "")
                   ? _meta.tags : (_meta.category !== undefined ? _meta.category : "")
        var arr = raw.split(",")
        var out = []
        for (var i = 0; i < arr.length && out.length < 4; ++i) {
            var t = arr[i].trim()
            if (t !== "")
                out.push(t)
        }
        page._tags = out
    }

    function openReader() {
        var name = _meta.bookName !== undefined ? _meta.bookName : page.bookName
        var auth = _meta.author !== undefined ? _meta.author : page.author
        var cover = _meta.coverUrl !== undefined ? _meta.coverUrl : page.coverUrl
        fanqie.openBook(bookId, name, auth, cover, continueChapter, continueFraction)
        stack.openReader({
            initialChapter: continueChapter,
            initialFraction: continueFraction
        })
    }

    Connections {
        target: fanqie
        function onBookDetailReady(meta, ok, err) {
            if (!ok) {
                // 失败时 meta 是空 map，先处理失败再比对 bookId
                page._detailLoading = false
                page._detailFailed = true
                return
            }
            if (meta.bookId !== page.bookId)
                return
            page._meta = meta
            page.computeTags()
            page._detailLoading = false
            page._detailFailed = false
        }
        function onDownloadsChanged() {
            page.refreshShelf()
        }
    }

    // 详情加载失败：点击重试
    Item {
        anchors.fill: parent
        visible: page._detailFailed

        Text {
            font.family: Theme.fontFamily
            anchors.centerIn: parent
            font.pixelSize: Theme.fontBody
            color: Theme.danger
            text: "加载失败，点击重试"

            MouseArea {
                anchors.fill: parent
                onClicked: {
                    page._detailFailed = false
                    page._detailLoading = true
                    fanqie.loadBookDetail(bookId)
                }
            }
        }
    }

    // 详情加载中
    LoadingOverlay {
        anchors.fill: parent
        active: page._detailLoading
        hint: "加载详情…"
    }
}
