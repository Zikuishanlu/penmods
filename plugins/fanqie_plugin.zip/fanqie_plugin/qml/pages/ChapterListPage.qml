import QtQuick 2.12
import ".."
import "../ui"

// 章节目录：按卷分组，全部章节可点（VIP 章内容接口同样可取）
Item {
    id: page

    property var stack: null
    property string bookId: ""
    property string bookName: ""
    property string author: ""
    property string coverUrl: ""

    property bool _tocLoading: true
    property bool _tocFailed: false

    Item {
        id: header
        height: 20
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right

        Text {
            font.family: Theme.fontFamily
            anchors.left: parent.left
            anchors.leftMargin: 10
            anchors.verticalCenter: parent.verticalCenter
            font.pixelSize: Theme.fontBody
            color: Theme.textDim
            elide: Text.ElideRight
            width: parent.width - 20
            text: bookName !== "" ? bookName + " · 目录" : "目录"
        }
    }

    ListView {
        id: list
        anchors.top: header.bottom
        anchors.topMargin: 6
        anchors.left: parent.left
        anchors.leftMargin: 6
        anchors.right: sliderArea.left
        anchors.rightMargin: 2
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 6
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        model: fanqie.chapterModel
        spacing: 1

        section.property: "volume"
        section.criteria: ViewSection.FullString
        section.delegate: Rectangle {
            width: list.width
            height: 18
            color: "transparent"
            Text {
                font.family: Theme.fontFamily
                anchors.left: parent.left
                anchors.leftMargin: 2
                anchors.verticalCenter: parent.verticalCenter
                font.pixelSize: Theme.fontSmall
                color: Theme.textFaint
                text: section
            }
        }

        delegate: Rectangle {
            width: list.width
            height: 26
            radius: 3
            color: model.index === fanqie.chapterModel.currentIndex ? Theme.accentDim : "transparent"

            // 整行可点打开章节；重试按钮画在它上面（后声明），优先命中
            MouseArea {
                anchors.fill: parent
                onClicked: {
                    // VIP 标记只是保守提示，内容接口实测可取，全部章节照常打开
                    openChapter(model.index)
                }
            }

            Row {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                anchors.leftMargin: 6
                anchors.rightMargin: model.failed ? 52 : 6
                spacing: 6

                Text {
                    font.family: Theme.fontFamily
                    width: parent.width - (model.failed ? 44 : 0)
                    font.pixelSize: Theme.fontBody
                    color: model.failed ? Theme.danger : Theme.text
                    elide: Text.ElideRight
                    text: model.title
                }

                // 下载失败标记：目录里红字提示，仍可点开阅读
                Text {
                    visible: model.failed
                    font.family: Theme.fontFamily
                    font.pixelSize: Theme.fontSmall
                    color: Theme.danger
                    text: "下载失败"
                }
            }

            // 失败章节重试（一个一个触发），重试任务会出现在下载列表里
            Btn {
                visible: model.failed
                anchors.right: parent.right
                anchors.rightMargin: 4
                anchors.verticalCenter: parent.verticalCenter
                btnWidth: 44; btnHeight: 20
                text: "重试"
                fill: Theme.accentDim
                textColor: "white"
                pixelSize: Theme.fontSmall
                onClicked: fanqie.retryChapter(page.bookId, page.bookName, model.index)
            }
        }
    }

    // 右侧快速定位滑块：长目录拖动秒跳，内容没超一屏时不显示
    Item {
        id: sliderArea
        anchors.top: header.bottom
        anchors.topMargin: 6
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 6
        anchors.right: parent.right
        anchors.rightMargin: 3
        width: 22   // 点击区加宽，视觉轨道仍是细线
        visible: list.contentHeight > list.height

        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.top: parent.top
            anchors.bottom: parent.bottom
            width: 3
            radius: 1.5
            color: Theme.divider
        }

        Rectangle {
            id: sliderHandle
            anchors.horizontalCenter: parent.horizontalCenter
            width: 4
            height: 20
            radius: 2
            color: Theme.accent
            y: list.visibleArea.yPosition * (sliderArea.height - height)
        }

        MouseArea {
            anchors.fill: parent
            onPressed: seek(mouse.y)
            onPositionChanged: seek(mouse.y)

            function seek(y) {
                if (list.contentHeight <= list.height)
                    return
                var range = sliderArea.height - sliderHandle.height
                var f = Math.max(0, Math.min(1, (y - sliderHandle.height / 2) / range))
                list.contentY = f * (list.contentHeight - list.height)
            }
        }
    }

    // 目录加载失败：点击重试
    Item {
        anchors.top: header.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        visible: page._tocFailed

        Text {
            font.family: Theme.fontFamily
            anchors.centerIn: parent
            font.pixelSize: Theme.fontBody
            color: Theme.danger
            text: "目录加载失败，点击重试"

            MouseArea {
                anchors.fill: parent
                onClicked: {
                    page._tocFailed = false
                    page._tocLoading = true
                    fanqie.loadDirectory(bookId)
                }
            }
        }
    }

    // 目录加载中
    LoadingOverlay {
        anchors.top: header.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        active: page._tocLoading
        hint: "加载目录…"
    }

    function openChapter(index) {
        fanqie.chapterModel.currentIndex = index
        fanqie.openBook(bookId, bookName, author, coverUrl, index, 0)
        stack.openReader({ initialChapter: index })
    }

    Component.onCompleted: {
        fanqie.loadDirectory(bookId)
    }

    Connections {
        target: fanqie
        function onDirectoryLoaded(id, ok) {
            if (id !== page.bookId)
                return
            page._tocLoading = false
            page._tocFailed = !ok
        }
        // 重试的章节下载完成后刷新目录，更新失败标记
        function onTaskFinished(bookId, ok, err) {
            if (bookId === page.bookId)
                fanqie.loadDirectory(bookId)
        }
    }
}
