import QtQuick 2.12
import ".."
import "../ui"

// 分类书单：展示某个分类下的书，点击进详情
Item {
    id: page

    property var stack: null
    property var category: null   // 中立分类参数，由分类页透传
    property string title: ""
    property bool _loading: true
    property bool _failed: false

    Item {
        id: header
        height: 20
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right

        Text {
            font.family: Theme.fontFamily
            anchors.left: parent.left
            anchors.leftMargin: 10
            anchors.right: parent.right
            anchors.rightMargin: 10
            anchors.verticalCenter: parent.verticalCenter
            font.pixelSize: Theme.fontBody
            color: Theme.textDim
            elide: Text.ElideRight
            text: page.title
        }
    }

    ListView {
        id: bookList
        anchors.top: header.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.margins: 6
        spacing: 4
        clip: true
        model: fanqie.discoverModel

        delegate: Rectangle {
            width: bookList.width
            height: 42
            radius: Theme.radiusSmall
            color: Theme.surface

            Row {
                anchors.fill: parent
                anchors.margins: 5
                spacing: 8

                CoverImage {
                    bookId: model.bookId
                    bookName: model.bookName
                    displayWidth: 26
                    displayHeight: 32
                    anchors.verticalCenter: parent.verticalCenter
                }

                Column {
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.width - 34
                    spacing: 2

                    Text {
                        font.family: Theme.fontFamily
                        width: parent.width
                        font.pixelSize: Theme.fontBody
                        color: Theme.text
                        elide: Text.ElideRight
                        text: model.bookName
                    }

                    Text {
                        font.family: Theme.fontFamily
                        width: parent.width
                        font.pixelSize: Theme.fontSmall
                        color: Theme.textDim
                        elide: Text.ElideRight
                        text: model.author
                    }
                }
            }

            MouseArea {
                anchors.fill: parent
                onClicked: {
                    stack.push("BookDetailPage", {
                        bookId: model.bookId,
                        bookName: model.bookName,
                        author: model.author,
                        coverUrl: model.coverUrl
                    })
                }
            }
        }

        // 加载更多：书单满一页时显示，点击拉下一页并追加
        footer: Item {
            width: bookList.width
            height: fanqie.discoverHasMore && bookList.count > 0 ? 34 : 0

            Btn {
                anchors.centerIn: parent
                visible: fanqie.discoverHasMore && bookList.count > 0
                btnWidth: 96; btnHeight: 26
                text: page._loading ? "加载中…" : "加载更多"
                fill: Theme.elevated
                textColor: Theme.text
                pixelSize: Theme.fontSmall
                enabled: !page._loading
                onClicked: fanqie.discoverMore()
            }
        }
    }

    // 空态覆盖层
    Item {
        anchors.top: header.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        visible: bookList.count === 0 && !page._loading && !page._failed

        Column {
            anchors.centerIn: parent
            spacing: 6
            Text {
                font.family: Theme.fontFamily
                anchors.horizontalCenter: parent.horizontalCenter
                font.pixelSize: Theme.fontBody
                color: Theme.textDim
                text: "该分类暂无内容"
            }
            Text {
                font.family: Theme.fontFamily
                anchors.horizontalCenter: parent.horizontalCenter
                font.pixelSize: Theme.fontSmall
                color: Theme.textFaint
                text: "试试其他分类"
            }
        }
    }

    // 加载失败：点击重试
    Item {
        anchors.fill: parent
        visible: page._failed

        Text {
            font.family: Theme.fontFamily
            anchors.centerIn: parent
            font.pixelSize: Theme.fontBody
            color: Theme.danger
            text: "加载失败，点击重试"

            MouseArea {
                anchors.fill: parent
                onClicked: {
                    page._failed = false
                    page._loading = true
                    fanqie.loadDiscover(category, 1)
                }
            }
        }
    }

    // 加载中
    LoadingOverlay {
        anchors.fill: parent
        active: page._loading
        hint: "加载中…"
    }

    Connections {
        target: fanqie
        function onDiscoverLoaded(ok) {
            page._loading = false
            // 追加下一页失败不算页面失败（footer 还在，可再点）；只有首页失败才提示
            if (!ok && bookList.count === 0)
                page._failed = true
        }
    }

    Component.onCompleted: {
        fanqie.loadDiscover(category, 1)
    }
}
