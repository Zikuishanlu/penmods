import QtQuick 2.12
import ".."
import "../ui"

// 搜索：输入框唤起宿主键盘，结果列表
Item {
    id: page

    property var stack: null
    property var pluginRoot: null
    property string _keyword: ""
    property var _keyboard: null

    // ---------- 输入条 ----------
    Item {
        id: inputBar
        height: 34
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.margins: 6

        Rectangle {
            id: inputBox
            anchors.left: parent.left
            anchors.right: searchBtn.left
            anchors.rightMargin: 6
            anchors.top: parent.top
            anchors.bottom: parent.bottom
            radius: 17
            color: Theme.surface
            border.color: Theme.divider
            border.width: 1

            TextInput {
                font.family: Theme.fontFamily
                id: inputField
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                anchors.leftMargin: 12
                anchors.rightMargin: 12
                font.pixelSize: Theme.fontBody
                color: Theme.text
                clip: true
                selectByMouse: true

                // 宿主键盘不可用时回退到直接编辑
                onAccepted: doSearch(text)

                Text {
                    font.family: Theme.fontFamily
                    anchors.fill: parent
                    visible: inputField.text.length === 0
                    font.pixelSize: Theme.fontBody
                    color: Theme.textFaint
                    text: "书名 / 作者"
                    elide: Text.ElideRight
                    verticalAlignment: Text.AlignVCenter
                }
            }

            // 点击唤起宿主键盘
            MouseArea {
                anchors.fill: parent
                onClicked: openHostKeyboard()
            }
        }

        Btn {
            id: searchBtn
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.bottom: parent.bottom
            btnWidth: 52
            btnHeight: parent.height
            text: "搜索"
            fill: Theme.accent
            onClicked: doSearch(inputField.text)
        }
    }

    // ---------- 结果列表 ----------
    ListView {
        id: resultList
        anchors.top: inputBar.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        clip: true
        model: fanqie.searchModel
        spacing: 4

        delegate: Rectangle {
            width: resultList.width
            height: 42
            radius: Theme.radiusSmall
            color: Theme.surface

            Row {
                anchors.fill: parent
                anchors.margins: 5
                spacing: 8

                CoverImage {
                    bookId: model.bookId
                    bookName: model.bookName
                    displayWidth: 26
                    displayHeight: 32
                    anchors.verticalCenter: parent.verticalCenter
                }

                Column {
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.width - 34
                    spacing: 2

                    Text {
                        font.family: Theme.fontFamily
                        width: parent.width
                        font.pixelSize: Theme.fontBody
                        color: Theme.text
                        elide: Text.ElideRight
                        text: model.bookName
                    }

                    Text {
                        font.family: Theme.fontFamily
                        width: parent.width
                        font.pixelSize: Theme.fontSmall
                        color: Theme.textDim
                        elide: Text.ElideRight
                        text: model.author
                    }
                }
            }

            MouseArea {
                anchors.fill: parent
                onClicked: {
                    stack.push("BookDetailPage", {
                        bookId: model.bookId,
                        bookName: model.bookName,
                        author: model.author,
                        coverUrl: model.coverUrl
                    })
                }
            }
        }

        // 加载更多：结果满一页（10 条）时显示，点击拉下一页并追加
        footer: Item {
            width: resultList.width
            height: fanqie.searchHasMore && resultList.count > 0 ? 34 : 0

            Btn {
                anchors.centerIn: parent
                visible: fanqie.searchHasMore && resultList.count > 0
                btnWidth: 96; btnHeight: 26
                text: fanqie.searching ? "加载中…" : "加载更多"
                fill: Theme.elevated
                textColor: Theme.text
                pixelSize: Theme.fontSmall
                enabled: !fanqie.searching
                onClicked: fanqie.searchMore()
            }
        }
    }

    // 空态覆盖层
    Item {
        anchors.top: inputBar.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        visible: resultList.count === 0

        Text {
            font.family: Theme.fontFamily
            anchors.centerIn: parent
            font.pixelSize: Theme.fontBody
            color: Theme.textFaint
            text: page._searched ? "没有找到相关书籍" : "输入关键词搜索"
        }
    }

    // 搜索中
    LoadingOverlay {
        anchors.top: inputBar.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        active: fanqie.searching
        hint: "搜索中…"
    }

    property bool _searched: false

    // ---------- 逻辑 ----------
    function doSearch(keyword) {
        var kw = keyword.trim()
        if (kw === "")
            return
        _keyword = kw
        _searched = true
        inputField.text = kw
        fanqie.search(kw)
        closeKeyboard()
    }

    function openHostKeyboard() {
        if (_keyboard)
            return
        var comp = Qt.createComponent("qrc:/qml/YInputPage.qml")
        if (comp.status !== Component.Ready) {
            // 宿主键盘不可用，回退到 TextInput 直接编辑
            inputField.focus = true
            comp.destroy()
            return
        }
        // 挂到插件根上，全屏盖住左栏
        var host = pluginRoot !== null ? pluginRoot : page
        var obj = comp.createObject(host, { placeHolderText: "书名 / 作者" })
        if (!obj) {
            comp.destroy()
            inputField.focus = true
            return
        }
        _keyboard = obj
        obj.inputFinished.connect(function(content) {
            doSearch(content)
        })
        obj.backButtonClicked.connect(function() {
            closeKeyboard()
        })
        // 已有文字回填进输入法
        if (inputField.text.length > 0) {
            try { obj.enterText(inputField.text) } catch (e) {}
        }
        obj.show()
    }

    function closeKeyboard() {
        if (_keyboard) {
            try { _keyboard.todoDestroy() } catch (e) {}
            _keyboard.destroy()
            _keyboard = null
        }
    }
}
